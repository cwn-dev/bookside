Bookside brand files. Everything here is vector: scale to any size without losing quality.

wordmark/  "Bookside." in Noto Serif Medium, text converted to outlines (no font needed)
icon/      Noto Serif SemiBold "B" on a rounded sienna square, 32x32 artboard

-light   for light backgrounds (dark text, sienna #8a4b2a)
-dark    for dark backgrounds (cream text, light sienna #e0956a)
-auto    switches with the viewer's light/dark setting (browsers only)
-light-square   icon with square corners, for platforms that round icons themselves

.svg for web and most design tools; .pdf for print, Illustrator, Affinity, Inkscape etc.
To make a PNG at any size: open the SVG in a browser or design tool and export,
or run:  rsvg-convert -w 1024 bookside-icon-light.svg -o icon-1024.png

Colours  light: text #23201c  accent #8a4b2a  cream #faf8f4
         dark:  text #ece7df  accent #e0956a  ink   #1b1410
Font     Noto Serif (SIL Open Font License)
